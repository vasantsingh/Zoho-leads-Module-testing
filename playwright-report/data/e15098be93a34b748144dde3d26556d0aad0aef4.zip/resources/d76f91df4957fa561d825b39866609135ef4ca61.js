var PW={
    lstm_Model : null,
    // Variable to store model generated after training
    // Variables to store data from the model training
     maxSequenceLength : null,
     modelLastTrainedTime:null,
     transitionToNumberMap:null, // Used for storing the value-path mapping for the model
     processUrlString:function(url) { // URL minimisation function
        url = url.split("?")[0];
        url = url.replace(/^\/|\/$/g, '');
        url = url.replace(/\/(\d+)\//g, '/idx/');
        if (url.indexOf('idx') === -1) {
            url = url.replace(/\/(\d+)/g, '/idx');
        } else {
            url = url.replace(/\/(\d+)/g, '/idy');
        } url = url.replace(/crm\/[a-zA-Z0-9]+\//, '')
    
        return url;
    },
    
    trainModel:async function(){
        let data = self.historyLogs
    let [featureTensors, targetTensors, totalTokenCount, trainingDataLength, sessioncount] = PW.processTrainingData(data);
    
    if(trainingDataLength < 400){
        self.postMessage({
            result: false, process: "Train" // NO I18N
        })
    }
    else{
    
    // Setting up the parameter for earlystopping during training
    let minEpochs = 15;         //no store variables
    let noImprovementCount = 0;//no store variables
    let epochsCompleted = 0;//no store variables
    let bestAccuracy = 0;//no store variables
    
    // callback function to monitor model training
    const customCallback = {
        onEpochEnd: async (epoch, logs) => {
            epochsCompleted++;
            
            // Early stopping after certain no.of epochs
            if (epochsCompleted >= minEpochs) {
                
                if (logs.acc > bestAccuracy) {
                    bestAccuracy = logs.acc;
                    noImprovementCount = 0;
                }
                else if(logs.acc >= 0.95 && noImprovementCount >= 1) {
                        PW.lstm_Model.stopTraining = true;
                    } else if (logs.acc >= 0.9 && noImprovementCount >= 3) {
                        PW.lstm_Model.stopTraining = true;
                    } else if (logs.acc >= 0.8 && noImprovementCount >= 5) {
                        PW.lstm_Model.stopTraining = true;
                    } else {
                        noImprovementCount++;
                    }
                
                
            }
        }
    };
    
    PW.lstm_Model = PW.createModel(totalTokenCount, PW.maxSequenceLength-1);
    
    let startTime = performance.now();
    
    var hist = await PW.lstm_Model.fit(featureTensors, targetTensors, {epochs: 100, callbacks: [customCallback] });
    
    let trainingAccuracy = hist.history.acc.slice(-1)[0];
    let trainingtime=((performance.now() - startTime)/1000).toFixed(3)
    
    PW.lstm_Model.save('indexeddb://lstm-model-1').then(() => { // NO I18N
    let modelJson = PW.lstm_Model.toJSON();
    let modelSizeBytes = new TextEncoder().encode(JSON.stringify(modelJson)).length;
    let modelSizeKB = modelSizeBytes / 1024;
    PW.modelLastTrainedTime=new Date().getTime()// eslint-disable-line @zoho/zohocrm/no-deprecated-fnc
    self.postMessage({
        // Training data is passed to main thread to store in indexedDB
        result: true,
        epochsCompleted:epochsCompleted,
        trainingDataLength:trainingDataLength,
        totalTokenCount:totalTokenCount,
        transitionToNumberMap: PW.transitionToNumberMap,
        time:trainingtime,
        modelsize:modelSizeKB,
        accuracy:trainingAccuracy,
        maxSequenceLength: PW.maxSequenceLength,
        modelLastTrainedTime:PW.modelLastTrainedTime,
        historyCount:self.historyCount,
        sessioncount:sessioncount,
        process: "Train" // no i18n
    })
    });
    
    
    
    // startTime = performance.now();
    // let loadedLSTMModel = await tf.loadLayersModel('indexeddb://lstm-model-1');//NO I18N
    
    
    // let [predictedValue, predictedTransition] = predictNextTransition(sequence, loadedLSTMModel, transitionToNumberMap, maxSequenceLength);
    
    // processTestingData(testingData, maxSequenceLength, totalTokenCount, transitionToNumberMap, loadedLSTMModel);
    
    }},
    
    createModel:function(totalTokenCount,maxSequenceLength){
    const model = tf.sequential();
    
    const inputLayer = tf.layers.embedding({
        inputDim: totalTokenCount+1,
        outputDim: 10,
        inputLength: maxSequenceLength
    });
    
    const lstmLayer = tf.layers.lstm({
        units: 100,
        recurrentInitializer: 'glorotUniform',//NO I18N
        returnSequences: false
    });
    
    const denseLayer = tf.layers.dense({
        units: totalTokenCount,
        activation: 'softmax'//NO I18N
    });
    
    model.add(inputLayer);
    model.add(lstmLayer);
    model.add(denseLayer);
    
    model.compile({
        optimizer: tf.train.adam(learningRate=0.005, beta1=0.01, beta2=0.1), //eslint-disable-line @zoho/webperf/no-global-variables
        loss: 'categoricalCrossentropy',//NO I18N
        metrics: ['accuracy']
    });
    model.summary();
    return model;
    },
    
    processTrainingData :(Data) => {
    let jsonData=[]
    Object.entries(Data).forEach(val=>{
        let obj={
            tabid:val[0],
            transition_list:val[1]
        }
        jsonData.push(obj)
    })
    jsonData.forEach(function(row) {
        if(row.transition_list) {
            row.transition_list = row.transition_list.map(PW.processUrlString);
        }
    });
    
    var uniqueTransitions = new Set();
    var sessioncount=jsonData.length
    jsonData.forEach(function(row) {
        if(row.transition_list) {
            row.transition_list.forEach(function(transition) {
                uniqueTransitions.add(transition);
            })
        }
    })
    
    
    PW.transitionToNumberMap = new Map();
    
    var total_word_count = 1;
    uniqueTransitions.forEach(function(transition) {
        PW.transitionToNumberMap.set(transition, total_word_count++);
    })
    PW.transitionToNumberMap.set('<oov>', total_word_count);
    
    jsonData.forEach(function(row){
        if(row.transition_list) {
            row.transition_list = row.transition_list.map(function(transition) {
                return PW.transitionToNumberMap.get(transition);
            });
        }
    })
    
    PW.maxSequenceLength=0;
    var tokenizedUrlArray = [];
    
    jsonData.forEach(function(row) {
        if(row.transition_list){
            var transitionArray = row.transition_list.slice();
            if (transitionArray.length > 2) {
                PW.maxSequenceLength = Math.max(PW.maxSequenceLength, transitionArray.length);
                var len=transitionArray.length-3
                for(var i=0; i<=len; i++){
                    var subArray = transitionArray.slice(0, i+3);
                    tokenizedUrlArray.push(subArray);
                }
            }
        }
    })
    
    tokenizedUrlArray = tokenizedUrlArray.slice(-400).slice(0, 400);
    
    var trainingDataLength = tokenizedUrlArray.length;
    
    var totalTokenCount = PW.transitionToNumberMap.size-1;
    
    
    var paddedTokensArray = tokenizedUrlArray.map(urlArray => {
        var paddingArray = Array(PW.maxSequenceLength - urlArray.length).fill(0);
        return [...paddingArray, ...urlArray];
    });
    
    let featureArray = paddedTokensArray.map(arr=> arr.slice(0, -1));
    let targetArray = paddedTokensArray.map(arr=> arr.slice(-1)[0]);
    
    let featureTensors = tf.tensor2d(featureArray);
    
    let numClasses = totalTokenCount;
    let targets = tf.oneHot(targetArray, numClasses);
    let targetTensors = tf.cast(targets, 'float32');//NO I18N
    
    
    return [featureTensors, targetTensors, totalTokenCount, trainingDataLength, sessioncount];
    
    },
    
    getKeyByValue : (targetValue, map) => {
    for(let [key, value] of map.entries()) {
        if(targetValue === value){
            return key;
        }
    }
    },
    
    
    
    predictNextTransition: function(inputSequence) {
    
        // Trim the sequence to the maximum sequence length used in training data
        const trimmedSequence = inputSequence.slice((-PW.maxSequenceLength)+1);
    
        // Encode the input sequence using the numberMap
        const encodedSequence = trimmedSequence.map(
            transition => PW.transitionToNumberMap.has(transition) ? PW.transitionToNumberMap.get(transition): PW.transitionToNumberMap.get('<oov>')
        );
    
        // Add padding to the inputSequence if the input sequence length is less than the maximum sequence length
        let paddings = Array(PW.maxSequenceLength - encodedSequence.length-1).fill(0);
        let paddedSequence = [...paddings, ...encodedSequence];
    
        // Convert the padded sequence into tensor
        let sequenceTensor = tf.tensor([paddedSequence]);
        let predictedTensor = PW.lstm_Model.predict(sequenceTensor);
        let predictedValue = tf.argMax(predictedTensor, axis=1); //eslint-disable-line @zoho/webperf/no-global-variables
        predictedValue = predictedValue.dataSync()[0];
    
        // Find the confidence percentage for the prediction
        let predictionConfidence = Math.max(...predictedTensor.dataSync());
    
        // Find the predicted transition using the numberMap
        let predictedTransition = PW.getKeyByValue(predictedValue, PW.transitionToNumberMap);
        
        // Dispose the tensors to clean up memory
        tf.dispose([sequenceTensor, predictedTensor]);
    
        return [predictionConfidence, predictedTransition];
    },
    
        PredictNextPage:async function () { // Function to predict the next page
        PW.logLocation(PW.processUrlString(self.transitionurl)) // Function to update locationlogs
        let predictionresult = [null,null]
        if (PW.lstm_Model === null) {
            try { 
                PW.lstm_Model = await tf.loadLayersModel('indexeddb://lstm-model-1') // NO I18N
    
            } catch (error) {
                ;
            }
        }
        if (self.historyCount > 20&&self.sequence.length>1&&self.predict===true) {
            if (PW.lstm_Model !== null) {
                if (PW.transitionToNumberMap === null || PW.transitionToNumberMap === undefined || PW.maxSequenceLength === null || PW.maxSequenceLength === undefined) {//eslint-disable-line @zoho/zstandard/no-duplicate-null-check
                    indexedDB.deleteDatabase("tensorflowjs") // no i18n
                    self.postMessage({
                        predresult: predictionresult[1],
                        predictionscore: predictionresult[0],
                        historyCount: self.historyCount,
                        historyLogs: self.historyLogs,
                        currentSession: self.currentSession,
                        currentSessionId: self.currentSessionID,
                        zgid: self.zgid,
                        sequence:self.sequence,
                        modelLastTrainedTime:PW.modelLastTrainedTime,
                        process: "Predict" // NO I18N
    
                    });
                } else {
    
                        predictionresult = await PW.predictNextTransition(self.sequence)
    
                        self.postMessage({
                            predresult: predictionresult[1],
                            predictionscore: predictionresult[0],
                            historyCount: self.historyCount,
                            historyLogs: self.historyLogs,
                            currentSession: self.currentSession,
                            currentSessionId: self.currentSessionID,
                            zgid: self.zgid,
                            sequence:self.sequence,
                            modelLastTrainedTime:PW.modelLastTrainedTime,
                            process: "Predict" // NO I18N
    
                        });
    
                 
                }
            } else {
                self.postMessage({
                    predresult: predictionresult[1],
                    predictionscore: predictionresult[0],
                    historyCount: self.historyCount,
                    historyLogs: self.historyLogs,
                    currentSession: self.currentSession,
                    currentSessionId: self.currentSessionID,
                    zgid: self.zgid,
                    sequence:self.sequence,
                    modelLastTrainedTime:PW.modelLastTrainedTime,
                    process: "Predict" // NO I18N
    
    
                });
            }
        } else {
            self.postMessage({
                predresult: predictionresult[1],
                predictionscore: predictionresult[0],
                historyCount: self.historyCount,
                historyLogs: self.historyLogs,
                currentSession: self.currentSession,
                currentSessionId: self.currentSessionID,
                zgid: self.zgid,
                sequence:self.sequence,
                modelLastTrainedTime:PW.modelLastTrainedTime,
                process: "Predict" // NO I18N
                
    
            });
        }
    }, 
    
    logLocation:function (pathName) { // Function to log locations to each session
        var currentSessionId = PW.getCurrentTime();
        var localJSONLog = self.historyLogs;
        var localLog = localJSONLog ? JSON.parse(localJSONLog) : {};
        var lastPage = localLog[currentSessionId] ? localLog[currentSessionId][localLog[currentSessionId].length - 1] : null;
    
        if (lastPage === pathName) {
            return;
        }
        if (localLog[currentSessionId] === null || localLog[currentSessionId] === undefined) { //eslint-disable-line @zoho/zstandard/no-duplicate-null-check
            localLog[currentSessionId] = []
        }
    
        self.historyCount = self.historyCount ? parseInt(self.historyCount) + 1 : parseInt(1);
        localLog[currentSessionId].push(pathName)
        self.sequence.push(pathName)
        self.historyLogs = JSON.stringify(localLog);
        if(self.historyCount>1500){
            var newLog={}
            var newCount=0
            var sessions=Object.keys(localLog).sort().reverse()
            var newSessions=[]
            sessions.every(function(session){
                if(newCount<1000){
                    if(newCount+localLog[session].length<1000){
                        newSessions.push(session)
                        newCount+=localLog[session].length
                        return true
                    }
                    else{
                        return false
                    }
                }
            })
            newSessions.sort()
            newSessions.forEach(function(session){
                newLog[session]=localLog[session]
            })
            self.historyCount=newCount
            self.historyLogs = JSON.stringify(newLog)
        }

    }, 
    
     getCurrentTime:function() { // To handle sessionIDs
    
        if (!self.currentSession) { //Don't change to Lyte, Lyte is not defined in the worker scope
            self.currentSessionID = new Date().getTime() // eslint-disable-line @zoho/zohocrm/no-deprecated-fnc
            self.currentSession = self.currentSessionID + self.actualzgid;
        }
        if (self.zgid !== self.actualzgid) {
            self.currentSession = self.currentSessionID + self.actualzgid;
            self.zgid = self.actualzgid;
        }
        return self.currentSession;
    } 
    }
    
    self.onmessage = function (e) { // Message received from Main thread
        if (e.data.process === "Initial") {
            importScripts(e.data.TF_url)
        } else if (e.data.process === "Train") {
            self.historyLogs = e.data.historyLogs;
            self.trainingstarttime = performance.now()
            PW.trainModel();
        } else if (e.data.process === "Predict") {
            self.historyCount = e.data.historyCount;
            self.historyLogs = e.data.historyLogs;
            self.transitionurl = e.data.transitionurl;
            self.currentSession = e.data.currentSession;
            self.currentSessionID = e.data.currentSessionID;
            self.zgid = e.data.zgid;
            self.actualzgid = e.data.zgidactual;
            if (PW.transitionToNumberMap === null) {
                PW.transitionToNumberMap = e.data.transitionToNumberMap; 
                PW.maxSequenceLength = e.data.maxSequenceLength;
                PW.modelLastTrainedTime =e.data.modelLastTrainedTime
            }
            self.sequence = e.data.sequence;
            self.predict=e.data.predict
            PW.PredictNextPage();
        }
    };
    
    