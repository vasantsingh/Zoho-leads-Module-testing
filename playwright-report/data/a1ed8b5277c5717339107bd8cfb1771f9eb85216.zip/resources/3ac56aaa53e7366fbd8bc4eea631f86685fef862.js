$(document).ready(function(){zwc_setSupportMail(true)});$(window).on("load",function(){zwc_setSupportMail(false)});function zwc_setMailToAnchorTag(t,a){const i=t.getAttribute("href").split(":")[1];if(i!=a){this.wantToSearchInNext=false}if(typeof a=="string"){if(i.split("?")[1]){a=`${a}?${i.split("?")[1]}`}t.setAttribute("href",`mailto:${a}`);if(t.textContent.includes("@"))t.textContent=a.split("?")[0]}}function zwc_folderMailCase(a,t){const i=t.Folder;if(this.wantToSearchInNext&&i){const s=Object.keys(i).find(t=>{if(window.location.pathname.includes(t)){return t}});if(s){let t=i[s];zwc_setMailToAnchorTag.call(this,a,t)}}}function zwc_langMailCase(t,a){const i=a.Language||{};const s=Object.keys(i).includes(currentUrlLang);const o=s&&i[currentUrlLang];if(this.wantToSearchInNext&&o)zwc_setMailToAnchorTag.call(this,t,o)}function zwc_countryMailCase(t,a){const i=a.Country||{};const s=Object.keys(i).includes(CountryCode);const o=s&&i[CountryCode];if(this.wantToSearchInNext&&o)zwc_setMailToAnchorTag.call(this,t,o)}function zwc_regionMailCase(t,a){const i=a.Region||{};const s=Object.keys(i).length;if(this.wantToSearchInNext&&s){if(customvar.isEU&&i["EU"])zwc_setMailToAnchorTag.call(this,t,i["EU"]);if(customvar.isAPAC&&i["APAC"])zwc_setMailToAnchorTag.call(this,t,i["APAC"]);if(customvar.isMEA&&i["MEA"])zwc_setMailToAnchorTag.call(this,t,i["MEA"]);if(customvar.isLAT&&i["LAT"])zwc_setMailToAnchorTag.call(this,t,i["LAT"]);if(customvar.isANZ&&i["ANZ"])zwc_setMailToAnchorTag.call(this,t,i["ANZ"])}}function zwc_setFooterMail(t){let a=customvar.productName?.replace(/\s+/g,"").toLowerCase();let i=customvar.isEU?t?.footer?.EU[a]||"support@zoho.com":t?.footer?.Default[a]||"support@zoho.com";const s=i.split(",");const o=s.length;var e=`<div class="ZF-support">
                            <div class="ZF-container ${o>1?"zf-multi-support-mail":""}">
                               <div class="ZF-contact">
                                    <ul>
                                        <li class="zf-support-mail">
                                            ${o>1?`<a id="zf-support-mailid" href="mailto:${s[0]}">${s[0]}</a> <a id="zf-support-mailid-1" href="mailto:${s[1]}">${s[1]}</a>`:`<a id="zf-support-mailid" href="mailto:${i}">${i}</a>`}
                                           
                                        </li>
                                        <li class="zglob-lang">
                                            <div class="ZF-dlsel">
                                                <div class="zdc-container">
                                                    <span class="zdc-text">Select DC</span>
                                                    <div class="zdc-container-inner">
                                                        <ul>
                                                            <li>
                                                                <a href="https://www.zoho.in/">IN DC</a>
                                                            </li>
                                                            <li>
                                                                <a href="https://www.zoho.com/">US DC</a>
                                                            </li>
                                                            <li>
                                                                <a href="https://www.zoho.eu/">EU DC</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                           </div>`;if(customvar.newFooterProducts.includes(customvar.productName)){o>1?`<a id="zf-support-mailid" href="mailto:${s[0]}">${s[0]}</a> <a id="zf-support-mailid-1" href="mailto:${s[1]}">${s[1]}</a>`:`<a id="zf-support-mailid" href="mailto:${i}">${i}</a>`;if(o>1){e=`<span class="zf-support-mail-wrap"><a id="zf-support-mailid" href="mailto:${s[0]}">${s[0]}</a> <a id="zf-support-mailid-1" href="mailto:${s[1]}">${s[1]}</a></span>`}else{e='<span class="zf-support-mail-wrap"><a id="zf-support-mailid" href="mailto:'+i+'">'+i+"</a></span>"}customvar.zwc_setnewFooter=function(){if($(".zw-support-mail-links").length>0){$(".zw-support-mail-links").html(e);if(o>1){$(".zw-support-mail-links").addClass("zf-multi-support-mail")}}};customvar.zwc_setnewFooter()}else{if($(".common-links").length>0){$(".common-links").prepend(e)}}}function zwc_setSupportMail(a){let t="";if(_preZ==window.location.hostname){t="https://"+_preZ+"/sites/zweb/json/dynamicemail.json"}else{t="https://www.zoho.com/sites/zweb/json/dynamicemail.json"}fetch(t).then(t=>t.json()).then(o=>{if(a){zwc_setFooterMail(o)}const t=document.querySelectorAll("a[href^='mailto']");t.forEach(function(t){this.wantToSearchInNext=true;const a=t.getAttribute("href").split(":")[1];const i=o.runningText.find(t=>t.Default==a.split("?")[0]);const s=t.getAttribute("data-mail-filter");if(i){if(s){switch(s.toUpperCase()){case"FOLDER":zwc_folderMailCase.call(this,t,i);break;case"LANGUAGE":zwc_langMailCase.call(this,t,i);break;case"COUNTRY":zwc_countryMailCase.call(this,t,i);break;case"REGION":zwc_regionMailCase.call(this,t,i);break;default:"";break}}else{zwc_regionMailCase.call(this,t,i);zwc_folderMailCase.call(this,t,i);zwc_langMailCase.call(this,t,i);zwc_countryMailCase.call(this,t,i)}}});if(typeof customvar.zwc_customSupportMail!="undefined"){customvar.zwc_customSupportMail()}}).catch(t=>{});if(typeof customvar.zwc_customSupportMail!="undefined"){customvar.zwc_customSupportMail()}}